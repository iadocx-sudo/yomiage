package jp.himmel.yomiage;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.drawable.Icon;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/** Foreground service: keeps reading alive with the screen off and shows lock-screen controls. */
public class PlaybackService extends Service {
    static final String CH = "playback";
    static final String A_TOGGLE = "jp.himmel.yomiage.TOGGLE";
    static final String A_BACK = "jp.himmel.yomiage.BACK";
    static final String A_FWD = "jp.himmel.yomiage.FWD";
    static final String A_CLOSE = "jp.himmel.yomiage.CLOSE";

    private MediaSession ms;
    private Engine eng;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean lastPlaying = false;
    private String lastTitle = "";

    @Override
    public void onCreate() {
        super.onCreate();
        eng = Engine.get(this);
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel ch = new NotificationChannel(CH, "読み上げ", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);

        ms = new MediaSession(this, "yomiage");
        ms.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { eng.resume(); }
            @Override public void onPause() { eng.pause(); }
            @Override public void onStop() { eng.pause(); }
            @Override public void onSkipToPrevious() { eng.skip(-1); }
            @Override public void onSkipToNext() { eng.skip(1); }
            @Override public void onRewind() { eng.skip(-1); }
            @Override public void onFastForward() { eng.skip(1); }
        });
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        ms.setSessionActivity(PendingIntent.getActivity(this, 10, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        ms.setActive(true);
        eng.listener = () -> h.post(this::refresh);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Must call startForeground promptly after startForegroundService().
        goForeground(build());
        String a = intent == null ? null : intent.getAction();
        if (A_TOGGLE.equals(a)) { if (eng.playing) eng.pause(); else eng.resume(); }
        else if (A_BACK.equals(a)) eng.skip(-1);
        else if (A_FWD.equals(a)) eng.skip(1);
        else if (A_CLOSE.equals(a)) { eng.pause(); stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); return START_NOT_STICKY; }
        refresh();
        return START_NOT_STICKY;
    }

    private void goForeground(Notification n) {
        try {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } catch (Exception e) {
            try { startForeground(1, n); } catch (Exception ignored) { }
        }
    }

    private PendingIntent act(String action, int code) {
        Intent i = new Intent(this, PlaybackService.class).setAction(action);
        return PendingIntent.getForegroundService(this, code, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification build() {
        boolean p = eng.playing;
        String t = eng.title == null || eng.title.isEmpty() ? "よみあげノート" : eng.title;
        Notification.Action back = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_back), "戻る", act(A_BACK, 1)).build();
        Notification.Action toggle = new Notification.Action.Builder(
                Icon.createWithResource(this, p ? R.drawable.ic_pause : R.drawable.ic_play),
                p ? "一時停止" : "再生", act(A_TOGGLE, 2)).build();
        Notification.Action fwd = new Notification.Action.Builder(
                Icon.createWithResource(this, R.drawable.ic_fwd), "進む", act(A_FWD, 3)).build();
        Intent open = new Intent(this, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return new Notification.Builder(this, CH)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(t)
                .setContentText((p ? "再生中 " : "一時停止中 ") + eng.rate + "×")
                .setContentIntent(PendingIntent.getActivity(this, 11, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT))
                .setDeleteIntent(act(A_CLOSE, 4))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(p)
                .setOnlyAlertOnce(true)
                .addAction(back)
                .addAction(toggle)
                .addAction(fwd)
                .setStyle(new Notification.MediaStyle()
                        .setMediaSession(ms.getSessionToken())
                        .setShowActionsInCompactView(0, 1, 2))
                .build();
    }

    private void refresh() {
        if (ms == null) return;
        boolean p = eng.playing;
        String t = eng.title == null ? "" : eng.title;
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_PLAY_PAUSE
                | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SKIP_TO_NEXT
                | PlaybackState.ACTION_REWIND | PlaybackState.ACTION_FAST_FORWARD | PlaybackState.ACTION_STOP;
        ms.setPlaybackState(new PlaybackState.Builder()
                .setActions(actions)
                .setState(p ? PlaybackState.STATE_PLAYING : PlaybackState.STATE_PAUSED,
                        PlaybackState.PLAYBACK_POSITION_UNKNOWN, p ? eng.rate : 0f)
                .build());
        if (!t.equals(lastTitle)) {
            ms.setMetadata(new MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, t.isEmpty() ? "よみあげノート" : t)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, "よみあげノート")
                    .build());
            lastTitle = t;
        }
        Notification n = build();
        if (p) {
            goForeground(n);
        } else {
            stopForeground(STOP_FOREGROUND_DETACH);
            getSystemService(NotificationManager.class).notify(1, n);
        }
        lastPlaying = p;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Keep reading if playing; otherwise clean up.
        if (!eng.playing) { stopForeground(STOP_FOREGROUND_REMOVE); stopSelf(); }
    }

    @Override
    public void onDestroy() {
        eng.listener = null;
        if (ms != null) { ms.setActive(false); ms.release(); ms = null; }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
